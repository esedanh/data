import datetime as dt
from pathlib import Path
import pandas as pd
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator



dag = DAG(                                                     
    dag_id="dag_1",                          
    start_date=dt.datetime(2019, 1, 1),                 
    schedule_interval=None,                                     
)

start = DummyOperator(task_id="start")
 
fetch_weather = BashOperator(
    task_id="fetch_weather",
    bash_command=(
    "mkdir -p /tmp/data && "
    "curl -o /tmp/data/data_weather.json "
    "https://raw.githubusercontent.com/esedanh/data/main/data_weather.json"
    ),
    dag=dag,
)

def _fetch_sales (input_path,output_path):
    data_sales = pd.read_json(input_path)
    df_data_sales = pd.DataFrame(data_sales)
    Path(output_path).parent.mkdir(exist_ok=True)
    df_data_sales.to_csv(output_path, index=False)
    print(df_data_sales)    


fetch_sales = PythonOperator(                              
    task_id="fetch_sales",                                
    python_callable=_fetch_sales,
    op_kwargs={'input_path': 'https://raw.githubusercontent.com/esedanh/data/main/data_sales.json','output_path':'/tmp/data/data_sales.csv'},
    dag=dag,
)

def _clean_weather (input_path,output_path):
    data_weather = pd.read_json(input_path)
    df_data_weather = pd.DataFrame(data_weather)
    data_weather_clean = df_data_weather[(df_data_weather["Dias_lluviosos"] > 0) & (df_data_weather["Horas_sol"] > 0) ]
    Path(output_path).parent.mkdir(exist_ok=True)
    data_weather_clean.to_csv(output_path, index=False)
    print(data_weather_clean)

clean_weather = PythonOperator(
    task_id="clean_weather",
    python_callable=_clean_weather,
    op_kwargs={
    "input_path": "/tmp/data/data_weather.json",
    "output_path": "/tmp/data/data_weather_clean.csv",
    },
    dag=dag,
)


def _clean_sales (input_path,output_path):
    data_sales = pd.read_csv(input_path)
    df_data_sales = pd.DataFrame(data_sales)
    data_sales_clean = df_data_sales[(df_data_sales["Cantidad"] > 0)]
    Path(output_path).parent.mkdir(exist_ok=True)
    data_sales_clean.to_csv(output_path, index=False)
    print(data_sales_clean)


clean_sales = PythonOperator(
    task_id="clean_sales",
    python_callable=_clean_sales,
    op_kwargs={
    "input_path": "/tmp/data/data_sales.csv",
    "output_path": "/tmp/data/data_sales_clean.csv",
    },
    dag=dag,
)

def _join_datasets (input_weather,input_sales,output_path):
    data_weather = pd.read_csv(input_weather)
    data_sales = pd.read_csv(input_sales)
    df_data_weather = pd.DataFrame(data_weather)
    df_data_sales = pd.DataFrame(data_sales)
    fusion = pd.merge(df_data_weather, df_data_sales, on=['Fecha','Departamento'])
    print(fusion)
    Path(output_path).parent.mkdir(exist_ok=True)
    fusion.to_csv(output_path, index=False)


join_datasets = PythonOperator(
    task_id="join_datasets",
    python_callable=_join_datasets,
    op_kwargs={
    "input_weather": "/tmp/data/data_weather_clean.csv",
    "input_sales": "/tmp/data/data_sales_clean.csv",
    "output_path": "/tmp/data/data_join.csv",
    },
    dag=dag,
)



train_ml = BashOperator(
    task_id="train_ml",
    bash_command="echo 'modelo entrenado'",
    dag=dag,
)


deploy_ml = BashOperator(
    task_id="deploy_ml",
    bash_command="echo 'modelo desplegado'",
    dag=dag,
)



start >> [fetch_weather,fetch_sales] 
fetch_weather >> clean_weather
fetch_sales >> clean_sales

[clean_weather,clean_sales] >> join_datasets >> train_ml >> deploy_ml
