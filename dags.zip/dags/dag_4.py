import datetime as dt
from pathlib import Path
import pandas as pd
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from datetime import datetime

ERP_CHANGE_DATE = datetime.strptime('21-05-31 00:00:00', '%y-%m-%d %H:%M:%S')


dag = DAG(                                                     
    dag_id="dag_4",                          
    start_date=dt.datetime(2019, 1, 1),                 
    schedule_interval=None,                                     
)

start = DummyOperator(task_id="start")

def _pick_erp_system (**context):
    var_contexto = context["execution_date"].strftime('%Y-%m-%d %H:%M:%S')
    if  datetime.strptime(var_contexto[2:19], '%y-%m-%d %H:%M:%S') < (ERP_CHANGE_DATE):
        return "fetch_sales_old"
    else:
        return "fetch_sales_new"


pick_erp_system = BranchPythonOperator(
    task_id="pick_erp_system",
    python_callable=_pick_erp_system,
    dag=dag
)
 
fetch_weather = BashOperator(
    task_id="fetch_weather",
    bash_command=(
    "mkdir -p /tmp/data && "
    "curl -o /tmp/data/data_weather.json "
    "https://raw.githubusercontent.com/esedanh/data/main/data_weather.json"
    ),
    dag=dag,
)


def _fetch_sales_old (**context):
    data_sales_old = pd.read_json('https://raw.githubusercontent.com/esedanh/data/main/data_sales.json')
    df_data_sales_old = pd.DataFrame(data_sales_old)
    Path('/tmp/data/data_sales_old.csv').parent.mkdir(exist_ok=True)
    df_data_sales_old.to_csv('/tmp/data/data_sales_old.csv', index=False)
    print(df_data_sales_old)
    print("Data de ERP antiguo")



def _fetch_sales_new (**context):
    data_sales_new = pd.read_csv('https://raw.githubusercontent.com/esedanh/data/main/data_sales_new2.csv')
    df_data_sales_new = pd.DataFrame(data_sales_new)
    Path('/tmp/data/data_sales_new.csv').parent.mkdir(exist_ok=True)
    df_data_sales_new.to_csv('/tmp/data/data_sales_new.csv', index=False)
    print(df_data_sales_new)
    print("Data de ERP nuevo")



fetch_sales_old = PythonOperator(                              
    task_id="fetch_sales_old",                                
    python_callable=_fetch_sales_old,
    dag=dag,
)

fetch_sales_new = PythonOperator(                              
    task_id="fetch_sales_new",                                
    python_callable=_fetch_sales_new,
    dag=dag,
)

def _clean_weather (input_path,output_path):
    data_weather = pd.read_json(input_path)
    df_data_weather = pd.DataFrame(data_weather)
    data_weather_clean = df_data_weather[(df_data_weather["Dias_lluviosos"] > 0) & (df_data_weather["Horas_sol"] > 0) ]
    Path(output_path).parent.mkdir(exist_ok=True)
    data_weather_clean.to_csv(output_path, index=False)
    print(data_weather_clean)

clean_weather = PythonOperator(
    task_id="clean_weather",
    python_callable=_clean_weather,
    op_kwargs={
    "input_path": "/tmp/data/data_weather.json",
    "output_path": "/tmp/data/data_weather_clean.csv",
    },
    dag=dag,
)

def _clean_sales_old (**context):
    data_sales_old = pd.read_csv('/tmp/data/data_sales_old.csv')
    df_data_sales_old = pd.DataFrame(data_sales_old)
    data_sales_old_clean = df_data_sales_old[(df_data_sales_old["Cantidad"] > 0)]
    Path('/tmp/data/data_sales_clean.csv').parent.mkdir(exist_ok=True)
    data_sales_old_clean.to_csv('/tmp/data/data_sales_clean.csv', index=False)
    print(data_sales_old_clean)


def _clean_sales_new (**context):
    data_sales_new = pd.read_csv('/tmp/data/data_sales_new.csv')
    df_data_sales_new = pd.DataFrame(data_sales_new).dropna()
    Path('/tmp/data/data_sales_clean.csv').parent.mkdir(exist_ok=True)
    df_data_sales_new.to_csv('/tmp/data/data_sales_clean.csv', index=False)
    print(df_data_sales_new)


clean_sales_old = PythonOperator(
    task_id="clean_sales_old",
    python_callable=_clean_sales_old,
    dag=dag,
)

clean_sales_new = PythonOperator(
    task_id="clean_sales_new",
    python_callable=_clean_sales_new,
    dag=dag,
)

def _join_datasets (input_weather,input_sales,output_path):
    data_weather = pd.read_csv(input_weather)
    data_sales = pd.read_csv(input_sales)
    print(data_sales)
    df_data_weather = pd.DataFrame(data_weather)
    df_data_sales = pd.DataFrame(data_sales)
    fusion = pd.merge(df_data_weather, df_data_sales, on=['Fecha','Departamento'])
    print(fusion)
    Path(output_path).parent.mkdir(exist_ok=True)
    fusion.to_csv(output_path, index=False)


join_datasets = PythonOperator(
    task_id="join_datasets",
    python_callable=_join_datasets,
    op_kwargs={
    "input_weather": "/tmp/data/data_weather_clean.csv",
    "input_sales": "/tmp/data/data_sales_clean.csv",
    "output_path": "/tmp/data/data_join.csv",
    },
    ##trigger_rule="none_failed",
    dag=dag,
)

join_branch = DummyOperator(
    task_id="join_erp_branch",
    trigger_rule="none_failed"
)


train_ml = BashOperator(
    task_id="train_ml",
    bash_command="echo 'modelo entrenado'",
    dag=dag,
)


deploy_ml = BashOperator(
    task_id="deploy_ml",
    bash_command="echo 'modelo desplegado'",
    dag=dag,
)



start >> [pick_erp_system, fetch_weather]
pick_erp_system >> [fetch_sales_old, fetch_sales_new]

fetch_weather >> clean_weather
fetch_sales_old >> clean_sales_old
fetch_sales_new >> clean_sales_new

[clean_sales_old, clean_sales_new] >> join_branch

[join_branch,clean_weather] >> join_datasets>> train_ml >> deploy_ml


